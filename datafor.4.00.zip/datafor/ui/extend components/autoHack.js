	/**
	 * @Description: 版本兼容处理模块(Version compatible processing module)
	 *
	 * 注： 请勿修改或删除该文件，否则可能引起系统异常
	 *
	 * Notice: Do not modify or delete this file, otherwise it may cause a system exception
	 *
	 * @Author: 美神猎手
	 * @Date:   2020-09-22T16:49:59+08:00
	 * @Email:  meishenlieshou@gmail.com
	 * @Project: Datafor
	 * @Filename: autoHack.js
	 * @Last modified by:   美神猎手
	 * @Last modified time: 2021-01-20T13:36:55+08:00
	 * @License: 收费
	 * @Copyright: 上海数为信息技术有限公司
	 */
	define("autoHack", ["Utility", "underscore", "promise", "Http", "jquery"], function (Utility, _, Promise, Http, $) {
		var toArray = function (arrayLike) {
			return Array.prototype.slice.call(arrayLike, 0);
		};
		return [
			// {
			// 	systemFrom: ["3.31", "3.3"], //兼容的版本。
			// 	/**
			// 	 * 当前系统版本与目标版本匹配时，系统将判断当前文件的保存版本是否在兼容版本列表中。如在兼容列表，系统将自动执行systemScanner任务
			// 	 * 对文件进行内容扫描并校正
			// 	 * @type {String}
			// 	 */
			// 	soft_version: "4.0", //目标版本。
			// 	/**
			// 	 * 扫描页面内容。且检测到不兼容内容，直接在contentRef中进行修改，并将返回值置为true，告诉系统当前扫描对页面内容做了兼容修复
			// 	 * @param       {[type]}                 contentRef 内容引用
			// 	 * @return      {[type]}                 检测返回值
			// 	 * @usage:
			// 	 * @author: 美神猎手
			// 	 * @email:      meishenlieshou@gmail.com
			// 	 * @copyrights: 上海数为信息技术有限公司
			// 	 * @time:       2020-09-22T21:09:57+080
			// 	 */
			// 	systemScanner: function (contentRef) {
			// 		return new Promise(function (resolve, reject) {
			// 			var changed = false;
			// 			changed = this.checkMeasureFilter(contentRef) || changed;
			// 			changed = this.checkMemberLimitation(contentRef) || changed;
			// 			changed = this.checkSelfFilter(contentRef) || changed;
			// 			resolve(changed);
			// 		});
			// 	},
			// 	/**
			// 	 * 检查指标过滤配置。
			// 	 * 指标过滤配置信息默认放在properties里，查询时动态插入查询对象。查询对象里检测到指标过滤信息，需要强行清空
			// 	 * @param       {[type]}                 content 内容
			// 	 * @return      {[type]}                 [description]
			// 	 * @usage:
			// 	 * @author: 美神猎手
			// 	 * @email:      meishenlieshou@gmail.com
			// 	 * @copyrights: 上海数为信息技术有限公司
			// 	 * @time:       2020-09-23T09:48:59+080
			// 	 */
			// 	checkMeasureFilter: function (content) {
			// 		var changed = false;
			// 		var travelHierarchy = function (hierarchies, axis) {
			// 			axis.filters = (axis.filters || []).filter(function (o) {
			// 				var valid = true;
			// 				return valid;
			// 			});
			// 			hierarchies.every(function (h) {
			// 				var levels = h ? h.levels : {};
			// 				var item;
			// 				var first;
			// 				var exp;
			// 				for(var i in levels) {
			// 					item = levels[i];
			// 					if(!item || !Array.isArray(item.filters) || item.filters.length == 0) continue;
			// 					first = item.filters[0];
			// 					if(!first || !Array.isArray(first.expressions) || first.expressions.length == 0) continue;
			// 					exp = String(first.expressions[0]).replace(/^\s+|\s+$/, "");
			// 					if(first.flavour === "Generic" && first["function"] === "Filter" && !first.operator && !!exp.match(/^\(?\s*\[Measures/)) {
			// 						//这是一个指标过滤，需要挪到轴上去
			// 						changed = true;
			// 						item.filters = [];
			// 					}
			// 				}
			// 				return true;
			// 			});
			// 		};
			// 		Array.isArray(content.children) && content.children.every(function (child) {
			// 			var axes = child && child.query && child.query.queryModel && child.query.queryModel.axes ? child.query.queryModel.axes : {};
			// 			var hierarchiesRow = axes.ROWS && axes.ROWS.hierarchies ? axes.ROWS.hierarchies : [];
			// 			var hierarchiesCol = axes.COLUMNS && axes.COLUMNS.hierarchies ? axes.COLUMNS.hierarchies : [];
			// 			axes.ROWS && travelHierarchy(hierarchiesRow, axes.ROWS);
			// 			axes.COLUMNS && travelHierarchy(hierarchiesCol, axes.COLUMNS);
			// 			return true;
			// 		});
			// 		//            console.log(content);
			// 		return changed;
			// 	},
			// 	/**
			// 	 * 成员数Top/Bottom限制
			// 	 * @param       {[type]}                 content 内容
			// 	 * @return      {[type]}                 [description]
			// 	 * @usage:
			// 	 * @author: 美神猎手
			// 	 * @email:      meishenlieshou@gmail.com
			// 	 * @copyrights: 上海数为信息技术有限公司
			// 	 * @time:       2020-09-23T20:15:03+080
			// 	 */
			// 	checkMemberLimitation: function (content) {
			// 		var changed = false;
			// 		//TODO
			// 		return changed;
			// 	},
			// 	checkSelfFilter: function (content) {
			// 		var changed = false;
			// 		//TDO
			// 		return changed;
			// 	}
			// },
			// {
			// 	systemFrom: ["3.31", "3.3", "4.0"], //兼容的版本。
			// 	/**
			// 	 * 模块描述
			// 	 * @type {String}
			// 	 */
			// 	description: "本模块主要处理较老的软件版本输出的datafor文件在新版本软件里打开运行时，因分析模型uniqueName编码差异造成的兼容问题",
			// 	/**
			// 	 * 当前系统版本与目标版本匹配时，系统将判断当前文件的保存版本是否在兼容版本列表中。如在兼容列表，系统将自动执行systemScanner任务
			// 	 * 对文件进行内容扫描并校正
			// 	 * @type {String}
			// 	 */
			// 	soft_version: "4.0", //目标版本。
			// 	/**
			// 	 * 小分支校验。只有在软件版本和内容版本一致时，执行这个检查
			// 	 * @param       {[type]}                 timestamp 文件版本的保存时间戳
			// 	 * @return      {[type]}                 [description]
			// 	 * @usage:
			// 	 * @author: 美神猎手
			// 	 * @email:      meishenlieshou@gmail.com
			// 	 * @copyrights: 上海数为信息技术有限公司
			// 	 * @time:       2020-12-31T09:35:09+080
			// 	 */
			// 	branch: function (timestamp, fileContent) {
			// 		return (timestamp || 0) < new Date("2021-01-15").getTime();
			// 	},
			// 	/**
			// 	 * 处理模型中可能存在的计算指标
			// 	 * @param       {[type]}                 xml [description]
			// 	 * @return      {[type]}                 [description]
			// 	 * @usage:
			// 	 * @author: 美神猎手
			// 	 * @email:      meishenlieshou@gmail.com
			// 	 * @copyrights: 上海数为信息技术有限公司
			// 	 * @time:       2021-01-05T18:56:36+080
			// 	 */
			// 	syncSchemaModel: function (xml) {
			// 		return new Promise(function (resolve, reject) {
			// 			//TODO
			// 			resolve(xml);
			// 		});
			// 	},
			// 	/**
			// 	 * 扫描文件中用到的schema
			// 	 * @param       {[type]}                 children [description]
			// 	 * @return      {[type]}                 [description]
			// 	 * @usage:
			// 	 * @author: 美神猎手
			// 	 * @email:      meishenlieshou@gmail.com
			// 	 * @copyrights: 上海数为信息技术有限公司
			// 	 * @time:       2021-01-04T15:15:22+080
			// 	 */
			// 	getSchemas: function (children) {
			// 		var promises = new Array();
			// 		var myself = this;
			// 		var list = _.uniq(children.filter(function (child) {
			// 			return child && child.query && child.query.cube;
			// 		}).map(function (child) {
			// 			return child.query.cube.schema;
			// 		}));
			// 		var instance = function (schemaName) {
			// 			return new Promise(function (resolve, reject) {
			// 				new Http(false, false, true).generalResources({
			// 					type: "get",
			// 					url: Utility.getURL("CUBE_XML", {
			// 						schema: schemaName
			// 					}),
			// 					complete: function (response, status) {
			// 						var matchV4 = "metamodelVersion='4.0'";
			// 						var already = "autoReplaced='true'";
			// 						var xml;
			// 						if(status == "success" || status == 200) {
			// 							xml = response.responseText;
			// 							//版本4的分析模型，或者版本3的分析模型但自动处理过，不需要处理
			// 							if(!!String(xml).match(matchV4) || !!String(xml).match(already)) {
			// 								resolve({
			// 									name: schemaName,
			// 									xml: xml
			// 								});
			// 							} else {
			// 								//更新模型，将模型中存在的计算指标涉及的uniqueName，替换为mondrian4的语法
			// 								myself.syncSchemaModel(xml).then(function (text) {
			// 									resolve({
			// 										name: schemaName,
			// 										xml: text
			// 									});
			// 								});
			// 							}
			// 						} else {
			// 							resolve({
			// 								name: schemaName,
			// 								xml: ''
			// 							});
			// 						}
			// 					},
			// 					error: function (error) {
			// 						if(typeof error === 'string') {
			// 							resolve({
			// 								name: schemaName,
			// 								xml: ''
			// 							});
			// 						}
			// 					}
			// 				});
			// 			});
			// 		};
			// 		list.every(function (schemaName) {
			// 			promises.push(instance(schemaName));
			// 			return true;
			// 		});
			// 		return promises;
			// 	},
			// 	/**
			// 	 * 获取维度
			// 	 * @param       {[type]}                 doc [description]
			// 	 * @return      {[type]}                 [description]
			// 	 * @usage:
			// 	 * @author: 美神猎手
			// 	 * @email:      meishenlieshou@gmail.com
			// 	 * @copyrights: 上海数为信息技术有限公司
			// 	 * @time:       2021-01-14T15:22:05+080
			// 	 */
			// 	getDimensions: function (doc) {
			// 		var dims = toArray(doc.querySelectorAll("Cube>DimensionUsage")).map(function (usage) {
			// 			var sourceName = usage.getAttribute("source");
			// 			var sourceNode = doc.querySelector("Dimension[name='" + sourceName + "']");
			// 			return {
			// 				name: usage.getAttribute("name") || sourceName,
			// 				element: sourceNode
			// 			};
			// 		});
			// 		dims = dims.concat(toArray(doc.querySelectorAll("Cube>Dimension")).map(function (d) {
			// 			return {
			// 				name: d.getAttribute("name"),
			// 				element: d
			// 			};
			// 		}));
			// 		return dims;
			// 	},
			// 	/**
			// 	 * 获取层级结构
			// 	 * @param       {[type]}                 doc [description]
			// 	 * @return      {[type]}                 [description]
			// 	 * @usage:
			// 	 * @author: 美神猎手
			// 	 * @email:      meishenlieshou@gmail.com
			// 	 * @copyrights: 上海数为信息技术有限公司
			// 	 * @time:       2021-01-14T15:22:16+080
			// 	 */
			// 	getHierarchies: function (doc) {
			// 		var getV3UniqueName = function (dName, hName, pName) {
			// 			return hName ? "[" + dName + "." + hName + "]" : "[" + dName + "]";
			// 		};
			// 		var getV4UniqueName = function (dName, hName, pName) {
			// 			return "[" + dName + "].[" + (hName || pName) + "]";
			// 		};
			// 		var hierarchies = new Array();
			// 		this.getDimensions(doc).every(function (item) {
			// 			var dName = item.name;
			// 			item.element && toArray(item.element.querySelectorAll("Hierarchy")).every(function (hNode) {
			// 				var pName = item.element.getAttribute("name");
			// 				var hName = hNode.getAttribute("name");
			// 				hierarchies.push({
			// 					m3: getV3UniqueName(dName, hName, pName).replace(/\[/g, "\\[").replace(/\]/g, "\\]").replace(/\./g, "\\."),
			// 					m4: getV4UniqueName(dName, hName, pName),
			// 					element: hNode
			// 				});
			// 				return true;
			// 			});
			// 			return true;
			// 		});
			// 		return hierarchies;
			// 	},
			// 	/**
			// 	 * 获取级别
			// 	 * @param       {[type]}                 doc [description]
			// 	 * @return      {[type]}                 [description]
			// 	 * @usage:
			// 	 * @author: 美神猎手
			// 	 * @email:      meishenlieshou@gmail.com
			// 	 * @copyrights: 上海数为信息技术有限公司
			// 	 * @time:       2021-01-14T15:22:24+080
			// 	 */
			// 	getLevels: function (doc) {
			// 		var levels = new Array();
			// 		this.getHierarchies(doc).every(function (item) {
			// 			var h3Name = item.m3;
			// 			var h4Name = item.m4;
			// 			toArray(item.element.querySelectorAll("Level")).every(function (levelNode) {
			// 				var name = levelNode.getAttribute("name");
			// 				var rId = "SWAP" + new Date().getTime() + Math.ceil(10000 * Math.random());
			// 				levels.push({
			// 					m3: h3Name + "\\.\\[" + name + "\\]",
			// 					swap: rId,
			// 					m4: h4Name + ".[" + name + "]",
			// 					element: levelNode
			// 				});
			// 				return true;
			// 			});
			// 			return true;
			// 		});
			// 		return levels;
			// 	},
			// 	/**
			// 	 * 替换Schame
			// 	 * @param       {[type]}                 schema      [description]
			// 	 * @param       {[type]}                 contentJSON [description]
			// 	 * @return      {[type]}                 [description]
			// 	 * @usage:
			// 	 * @author: 美神猎手
			// 	 * @email:      meishenlieshou@gmail.com
			// 	 * @copyrights: 上海数为信息技术有限公司
			// 	 * @time:       2021-01-14T15:22:33+080
			// 	 */
			// 	tryReplaceBySchema: function (schema, contentJSON) {
			// 		var doc = $.parseXML(schema);
			// 		var hierarchiesUniqueName = this.getHierarchies(doc);
			// 		var levelsUniqueName = this.getLevels(doc);
			// 		var children = JSON.stringify(contentJSON.children);
			// 		var changed = false;
			// 		levelsUniqueName.every(function (item) {
			// 			var r = new RegExp(item.m3, "g");
			// 			if(!changed) {
			// 				changed = !!children.match(r);
			// 			}
			// 			children = children.replace(r, item.swap);
			// 			return true;
			// 		});
			// 		hierarchiesUniqueName.every(function (item) {
			// 			var r = new RegExp('([^\\.])' + item.m3, "g"); //避免误伤Measures
			// 			if(!changed) {
			// 				changed = !!children.match(r);
			// 			}
			// 			children = children.replace(r, '$1' + item.m4);
			// 			return true;
			// 		});
			// 		levelsUniqueName.every(function (item) {
			// 			var r = new RegExp(item.swap, "g");
			// 			children = children.replace(r, item.m4);
			// 			return true;
			// 		});
			// 		contentJSON.children = JSON.parse(children);
			// 		return changed;
			// 	},
			// 	/**
			// 	 * 扫描页面内容。且检测到不兼容内容，直接在contentRef中进行修改，并将返回值置为true，告诉系统当前扫描对页面内容做了兼容修复
			// 	 *
			// 	 * 修复原理：
			// 	 * 拿到页面内容里涉及的所有schema。然后根据schema推算md4的name，逐个替换原有的uniqueName
			// 	 * @param       {[type]}                 contentRef 内容引用
			// 	 * @return      {[type]}                 检测返回值
			// 	 * @usage:
			// 	 * @author: 美神猎手
			// 	 * @email:      meishenlieshou@gmail.com
			// 	 * @copyrights: 上海数为信息技术有限公司
			// 	 * @time:       2020-09-22T21:09:57+080
			// 	 */
			// 	systemScanner: function (contentRef) {
			// 		var string = JSON.stringify(contentRef);
			// 		var schemas = this.getSchemas(contentRef.children);
			// 		var myself = this;
			// 		return new Promise(function (resolve, reject) {
			// 			var changed = false;
			// 			Promise.all(schemas).then(function (values) {
			// 				values.every(function (item) {
			// 					if(!item.xml) {
			// 						return true;
			// 					}
			// 					changed |= myself.tryReplaceBySchema(item.xml, contentRef);
			// 					return true;
			// 				});
			// 				resolve(changed);
			// 			}).catch(function (error) {
			// 				console.log(error);
			// 			});
			// 		});
			// 	}
			// }
		];
	});
