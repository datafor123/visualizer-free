/**
 * @Description:
 * @Author: 美神猎手
 * @Date:   2019-02-23T22:38:19+08:00
 * @Email:  meishenlieshou@gmail.com
 * @Project: Datafor
 * @Filename: dataInterface.js
 * @Last modified by:   美神猎手
 * @Last modified time: 2020-07-12T16:28:32+08:00
 * @License: 收费
 * @Copyright: 上海数为信息技术有限公司
 */


$(function() {
    var Utility = require('Utility');
    var $ = require('jquery');
    var CodeMirror = require('codemirror');
    var javaScript = require('javascript');
    var placeholder = require('placeholder');
    var Saiku = require('model/Saiku');
    var Component = require('model/Component');
    var Dashboard = require('model/Dashboard')
    var Events = require('Event');
    var Convert = require('lib/saiku.data.convert');
    var Selector = require('lib/backbone.select');
    var Loader = require('Loader');
    var DUtility = require('echartbase/Echart_cda');
    var CubeTreeNode = require('utility/CubeTreeNode');
    var Calculated = require('ui/CalculatedMeasureView');
    var URLParams = require('utility/params');
    var Http = require('Http');
    require('nicescroll');
    require('vim');
    require('pqgrid');

    $('.load-mask').remove();

    require('mdx');

    var isMdxMode = Boolean(URLParams.getGeneralParam('__mdx') == 'true');

    var backQuery;
    if (isMdxMode) {
        $('button.apply').html('提交（MDX）');
    } else {
        $('button.apply').html('提交（QUERYMODEL）');
    }


    (function(baseQuery, baseMDX) {


        var UI = {

            cubeList: new Array(),

            metadata: {},

            cube: {},

            getValidLevelNode: function(dimensions) {
                var msg = null;
                dimensions.every(function(dim) {
                    var hierarchies = dim.hierarchies;
                    if (Array.isArray(dim.hierarchies) && dim.hierarchies.length) {
                        dim.hierarchies.every(function(hierarchy) {
                            var levelNode;
                            if (Array.isArray(hierarchy.levels) && hierarchy.levels.length > 1) {
                                msg = {};
                                msg.name = hierarchy.uniqueName;
                                levelNode = hierarchy.levels[hierarchy.levels.length - 1];
                                msg.levels = {};
                                msg.cmembers = {};
                                msg.filters = [];
                                msg.levels[levelNode.name] = {
                                    name: levelNode.name,
                                    caption: levelNode.caption,
                                    mdx: null,
                                    selection: {
                                        type: 'INCLUSION',
                                        members: [],
                                        parameterName: null
                                    },
                                    aggregators: null,
                                    filters: []
                                }
                            }
                            return !msg;
                        });
                    }
                    return !msg;
                });
                return msg;
            },




            datasourceUpdate: function(value) {
                var id = Array.isArray(value) ? value[0] : value;
                var myself = this;
                var cube;
                if (!id) {
                    Events.trigger('TipNotify', {
                        controls: {
                            include: ['tip']
                        },
                        data: {
                            text: '请选中一个数据源',
                            duration: 2,
                            type: 'error'
                        }
                    });
                    return this;
                }
                cube = _.find(this.cubeList, function(o) {
                    return o.uniqueName == id;
                });
                if (!cube) {
                    Events.trigger('TipNotify', {
                        controls: {
                            include: ['tip']
                        },
                        data: {
                            text: "没有找到对应的数据源",
                            duration: 2,
                            type: 'error'
                        }
                    });
                    return this;
                }
                this.loader = new Loader();
                this.cube = Utility.deepCopy(cube);
                new CubeTreeNode({
                    cube: cube
                }).getNodes(function(data) {
                    baseQuery = Utility.deepCopy(backQuery);
                    myself.loader && myself.loader.remove();
                    baseQuery.cube = Utility.deepCopy(cube);
                    if (!data || !Array.isArray(data.dimensions) || !Array.isArray(data.measures)) {
                        Events.trigger('TipNotify', {
                            controls: {
                                include: ['tip']
                            },
                            data: {
                                text: "数据源可能已经损坏",
                                duration: 2,
                                type: 'error'
                            }
                        });
                        return;
                    }
                    baseQuery.queryModel.axes.ROWS.hierarchies = [myself.getValidLevelNode(data.dimensions)];
                    if (data.measures.length) {
                        baseQuery.queryModel.details.measures = [{
                            "caption": data.measures[0].caption,
                            "name": data.measures[0].name,
                            "uniqueName": data.measures[0].uniqueName,
                            "type": "EXACT"
                        }];
                    } else {
                        Events.trigger('TipNotify', {
                            controls: {
                                include: ['tip']
                            },
                            data: {
                                text: "数据源中没有指标",
                                duration: 2,
                                type: 'error'
                            }
                        });
                    }
                    myself.metadata = data || {};
                    myself.contentUpdate();
                });
                return this;
            },

            getDatasourcesList: function(callback) {
                var myself = this;
                this.cubeList = new Array();
                new Http().getResources(Utility.getURL('MODELS_LIST'), {}, function(data) {
                    var list = new Array();
                    Array.isArray(data) && data.every(function(connection) {
                        Array.isArray(connection.catalogs) && connection.catalogs.every(function(catalog) {
                            Array.isArray(catalog.schemas) && catalog.schemas.every(function(schema) {
                                Array.isArray(schema.cubes) && schema.cubes.every(function(cube) {
                                    myself.cubeList.push(Utility.deepCopy(cube));
                                    list.push({
                                        id: cube.uniqueName,
                                        text: cube.schema + ' -> ' + cube.caption,
                                        name: cube.name
                                    });
                                    return true;
                                });
                                return true;
                            });
                            return true;
                        });
                        return true;
                    });
                    myself.selector.model.unset('datasets', {
                        silent: true
                    });
                    myself.selector.model.set('datasets', list);
                    _.isFunction(callback) && callback(list);
                    myself.loader && myself.loader.remove();
                });
                return this;
            },

            getValidUniqueName: function(dimensions) {
                var msg = null;
                dimensions.every(function(dim) {
                    var hierarchies = dim.hierarchies;
                    if (Array.isArray(dim.hierarchies) && dim.hierarchies.length) {
                        dim.hierarchies.every(function(hierarchy) {
                            var levelNode;
                            if (Array.isArray(hierarchy.levels) && hierarchy.levels.length > 1) {
                                levelNode = hierarchy.levels[hierarchy.levels.length - 1];
                                msg = levelNode.uniqueName;
                            }
                            return !msg;
                        });
                    }
                    return !msg;
                });
                return msg;
            },

            getSampleMDX: function() {
                var uniqueName = this.getValidUniqueName(this.metadata.dimensions);
                var mUniqueName = this.metadata.measures[0].uniqueName;
                var cubeName = this.cube.name;
                var mdx = "WITH SET [~ROWS] AS {" + uniqueName + ".Members} \n" +
                    "SELECT \n" +
                    "\tNON EMPTY {" + mUniqueName + "} ON COLUMNS, \n" +
                    "\tNON EMPTY [~ROWS] ON ROWS \n" +
                    "FROM [" + cubeName + "]";
                return mdx;
            },


            contentUpdate: function() {
                if (isMdxMode) {
                    this._coder.getDoc().setValue(this.getSampleMDX());
                } else {
                    this._coder.getDoc().setValue(JSON.stringify(Utility.deepCopy(baseQuery), '\t', 8));
                }
                return this;
            },



            init: function() {
                var sizey = $('.CodeMirror-vscrollbar>div').height();
                var myself = this;
                var container = $('.ctable>div');
                var fmode = 'flattened';
                var vim = Boolean(URLParams.getGeneralParam('__vim') == 'true');
                var configs = {
                    theme: 'datafor',
                    tabSize: 8,
                    mode: isMdxMode ? "text/x-mdx" : "application/ld+json",
                    indentWithTabs: true,
                    cursorHeight: 1,
                    lineNumbers: true,
                    indentUnit: 8
                };
                if (vim) {
                    configs.keyMap = 'vim';
                }
                backQuery = Utility.deepCopy(baseQuery);
                this._coder = CodeMirror.fromTextArea(document.querySelector('.text-content'), configs);
                $('.viewmsg').click(function() {
                    Events.trigger('FUNCTION_EDITOR', {
                        controls: {
                            include: ['Alert']
                        },
                        data: {
                            vim: vim,
                            sizey: '500',
                            callback: function() {},
                            title: '当前数据源的指标和维度元数据',
                            content: JSON.stringify(myself.metadata, '\t', 4),
                            shown: function(dialog) {}
                        }
                    });
                });
                this.selector = new Selector({
                    model: new Selector.Model({
                        multiple: false,
                        singleRequireSelected: true,
                        placeholder: '请选择数据源',
                        datasets: [{
                            id: 'a',
                            text: 'A BDC',
                            disable: false,
                            icon: ''
                        }],
                        height: 34,
                        updated: this.datasourceUpdate.bind(this)
                    })
                });
                var placeholders = [
                    "MDX模式，请先选择数据源，然后在这里输入MDX查询",
                    "QUERYMODEL模式，请先选择数据源，然后在这里修改查询"
                ];
                this._coder.on('keyHandled', function(instance, name, event) {
                    if (window.event) {
                        event.cancelBubble = true;
                    } else {
                        event.stopPropagation();
                    }
                });
                $('.text-content').attr('placeholder', isMdxMode ? placeholders[0] : placeholders[1]);
                $('.datasource>.list').append(this.selector.$el);
                if (isMdxMode) {
                    this.formatter = new Selector({
                        model: new Selector.Model({
                            multiple: false,
                            search: false,
                            selected: [fmode],
                            singleRequireSelected: true,
                            placeholder: '选择格式类型',
                            datasets: [{
                                id: 'mix',
                                text: 'mix',
                            }, {
                                id: 'flattened',
                                text: 'flattened'
                            }, {
                                id: 'flat',
                                text: 'flat'
                            }],
                            sizex: 360,
                            height: 34,
                            updated: function(value) {
                                value = Array.isArray(value) ? value[0] : value;
                                fmode = value;
                            }
                        })
                    });
                    $('.formatter-label').show();
                    $('.datasource>.formatter').show().append(this.formatter.$el);
                } else {
                    $('.formatter-label').hide();
                    $('.datasource>.formatter').hide();
                }
                this.getDatasourcesList();
                this.loader = new Loader({
                    container: this.selector.$el,
                    layout: 'absolute'
                });

                var cache = null;
                $('.btn.apply').on('click', function() {
                    var _baseQuery = Utility.deepCopy(baseQuery);
                    var value = myself._coder.getDoc().getValue();
                    var component = new Saiku();
                    var query = new Component();
                    var page = new Dashboard();
                    var element = $('.CodeMirror-scroll');
                    query.parent = page;
                    query.execute = component.execute.bind(query);
                    if (!isMdxMode) {
                        try {
                            var top = element.scrollTop();
                            value = JSON.parse(value);
                            var target = null;
                            Array.isArray(value.queryModel.calculatedMeasures) && value.queryModel.calculatedMeasures.every(function(item) {
                                if (item && item.name.match(/^__.*/g)) {
                                    target = item;
                                    return false;
                                }
                                return true;
                            });
                            if (target) {
                                var content = new Calculated({
                                    model: new Calculated.Model({
                                        measuresArray: [],
                                        create: false,
                                        formula: cache ? cache.formula : '',
                                        name: cache ? cache.name : target.name
                                    })
                                });
                                //console.log(target);
                                Events.trigger('BOOTSTRAP_DIALOG', {
                                    controls: {
                                        include: ['Alert']
                                    },
                                    data: {
                                        content: content.el,
                                        type: 1,
                                        size: 'l',
                                        helplink: false,
                                        metadata: true,
                                        title: Utility.locale('panel', 'data panel', 'create calculated measure'),
                                        autoclose: false,
                                        onshown: function() {
                                            content.render();
                                        },
                                        confirm: function(ok, dialog) {
                                            var attrs = content.getValue();
                                            var f;
                                            if (!ok) {
                                                dialog.close();
                                                return;
                                            } else {
                                                cache = Utility.deepCopy(attrs);
                                                attrs.formula = attrs.formula.replace(/\r|\n|\t/g, '');
                                                target.name = attrs.name;
                                                target.formula = attrs.formula;
                                                target.uniqueName = attrs.uniqueName;
                                                target.hierarchyName = '[Measures]';
                                                target.properties = {};
                                                dialog.close();
                                                query.set({
                                                    query: value
                                                }, {
                                                    silent: true
                                                });
                                                query.execute();
                                            }
                                        }
                                    }
                                });
                            } else {
                                myself._coder.getDoc().setValue(JSON.stringify(value, '\t', 4));
                                element.scrollTop(top);
                                query.set({
                                    query: value
                                }, {
                                    silent: true
                                });
                                query.execute();
                            }
                        } catch (e) {
                            Events.trigger('TipNotify', {
                                controls: {
                                    include: ['tip']
                                },
                                data: {
                                    text: "配置格式有误",
                                    duration: 2,
                                    type: 'error'
                                }
                            });
                        }
                    }
                    $(this).blur();
                    Events.COMPONENT_QUERY_SUCCESS(query.id, 0, function(data) {
                        var datalist = new Array();
                        var raw = data.data;
                        var colModel = [];
                        var dataArray = new Array(['No data']);
                        var options;
                        if (data && data.raw && Array.isArray(data.raw.cellset) && data.raw.cellset.length) {
                            dataArray.splice(0);
                            data.raw.cellset.every(function(item) {
                                var list = new Array();
                                item.every(function(o) {
                                    list.push(o ? o.value : '');
                                    return true;
                                });
                                dataArray.push(list);
                                return true;
                            });
                        }
                        options = {
                            showHeader: false,
                            showToolbar: false,
                            showTop: false,
                            height: '100%',
                            stripeRows: true,
                            title: null,
                            numberCell: {
                                resizable: true,
                                title: "#"
                            },
                            columnTemplate: {
                                width: 160
                            },
                            selectionModel: {
                                type: '',
                                native: true
                            },
                            bootstrap: {
                                on: true,
                                thead: 'table table-striped table-condensed table-bordered',
                                tbody: 'table table-striped table-condensed table-bordered',
                                grid: 'panel panel-default'
                            },
                            hwrap: true,
                            wrap: true,
                            scrollModel: {
                                autoFit: false
                            },
                            dragColumns: {
                                enabled: false
                            },
                            collapsible: {
                                on: false,
                                toggle: false
                            },
                            stripeRows: true,
                            editable: false,
                            sortModel: {
                                on: false
                            },
                            showBottom: false,
                            refresh: function() {
                                var view = container.find('.pq-body-outer .pq-cont-right');
                                var scroll = view.getNiceScroll();
                                if (scroll && scroll.length) {
                                    _.delay(function() {
                                        scroll.resize();
                                    }, 100);
                                } else {
                                    view.niceScroll({
                                        cursorwidth: 10,
                                        cursorcolor: '#aaa',
                                        cursorborder: 'none',
                                        autohidemode: 'leave'
                                    });
                                }
                            },
                            resizable: true,
                            dataModel: {
                                data: dataArray
                            },
                            freezeRows: (function(msg) {
                                return data.raw && Array.isArray(data.raw.cellset) && data.raw.cellset.length ? (new Component({
                                    query: msg
                                }).getAxesLevels('COLUMNS').length + 1) : 0;
                            })(data && data.raw ? data.raw.query : {}),
                            freezeCols: (function(msg) {
                                return data.raw && Array.isArray(data.raw.cellset) && data.raw.cellset.length ? (new Component({
                                    query: msg
                                }).getAxesLevels('ROWS').length) : 0;
                            })(data && data.raw ? data.raw.query : {})
                        };
                        try {
                            container.pqGrid('destroy');
                        } catch (e) {}
                        $('.data-content').show().find('.canvas-content').animate({
                            height: 500
                        }, 200, function() {
                            container.pqGrid(options);
                            try {
                                $('.data-content').find('.mdx-content').val(data.raw && data.raw.query && data.raw.query.mdx ? data.raw.query.mdx : '');
                            } catch (e) {}
                            Events.off_COMPONENT_QUERY_SUCCESS(query.id);
                        });
                    });
                    if (isMdxMode) {
                        _baseQuery.type = "MDX";
                        _baseQuery.mdx = value;
                        _baseQuery.properties['saiku.olap.result.formatter'] = fmode || 'flattened';
                        query.set({
                            query: _baseQuery
                        }, {
                            silent: true
                        });
                        query.execute();
                    } else {}
                });
                $('.data-content').on('click', function(event) {
                    var target = $(event.target);
                    if (target.closest('.ctable').length || target.hasClass('mdx-content')) {
                        event.stopPropagation();
                        return this;
                    }
                    try {
                        container.pqGrid('destroy');
                    } catch (e) {
                        console.log(e.message);
                    }
                    $('.data-content').find('.canvas-content').animate({
                        height: 0
                    }, 200, function() {
                        target.closest('.data-content').hide();
                    });
                });
            }
        };

        UI.init();
    })({
            "cube": {
                "uniqueName": "[SteelWheels].[SteelWheels].[SteelWheels].[SteelWheelsSales]",
                "name": "SteelWheelsSales",
                "connection": "SteelWheels",
                "catalog": "SteelWheels",
                "schema": "SteelWheels",
                "caption": "SteelWheelsSales",
                "visible": true
            },
            "queryModel": {
                "axes": {
                    "FILTER": {
                        "mdx": null,
                        "filters": [],
                        "sortOrder": null,
                        "sortEvaluationLiteral": null,
                        "hierarchizeMode": null,
                        "location": "FILTER",
                        "hierarchies": [],
                        "nonEmpty": false
                    },
                    "COLUMNS": {
                        "mdx": null,
                        "filters": [],
                        "sortOrder": null,
                        "sortEvaluationLiteral": null,
                        "hierarchizeMode": null,
                        "location": "COLUMNS",
                        "hierarchies": [],
                        "nonEmpty": true
                    },
                    "ROWS": {
                        "mdx": null,
                        "filters": [],
                        "sortOrder": null,
                        "sortEvaluationLiteral": null,
                        "hierarchizeMode": null,
                        "location": "ROWS",
                        "hierarchies": [{
                            "name": "[Time]",
                            "levels": {
                                "Years": {
                                    "name": "Years",
                                    "caption": "Years",
                                    "mdx": null,
                                    "selection": {
                                        "type": "INCLUSION",
                                        "members": [],
                                        "parameterName": null
                                    },
                                    "aggregators": [],
                                    "filters": []
                                }
                            },
                            "cmembers": {},
                            "filters": []
                        }],
                        "nonEmpty": true
                    }
                },
                "visualTotals": false,
                "visualTotalsPattern": null,
                "lowestLevelsOnly": false,
                "details": {
                    "axis": "COLUMNS",
                    "location": "BOTTOM",
                    "measures": []
                },
                "calculatedMeasures": [],
                "calculatedMembers": []
            },
            "queryType": "OLAP",
            "properties": {
                "saiku.olap.query.automatic_execution": true,
                "saiku.olap.query.nonempty": true,
                "saiku.olap.query.nonempty.rows": true,
                "saiku.olap.query.nonempty.columns": true,
                "saiku.ui.render.mode": "chart",
                "saiku.ui.render.type": "table",
                "saiku.olap.query.filter": true,
                "saiku.olap.result.formatter": "flattened",
                "org.saiku.query.explain": true,
                "org.saiku.connection.scenario": false,
                "saiku.olap.query.drillthrough": true,
                "datafor.query.location": null
            },
            "parameters": {},
            "plugins": {},
            "mdx": null,
            "name": "54655AFB-34A1-0B8E-80F0-284D4A45591B",
            "metadata": {},
            "type": "QUERYMODEL"
        },
        "WITH SET [~ROWS] AS {[Time].[Years].Members} SELECT NON EMPTY {[Measures].[Quantity]} ON COLUMNS, NON EMPTY [~ROWS] ON ROWS FROM [SteelWheelsSales]"
    );
});