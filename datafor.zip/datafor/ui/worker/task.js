/**
 * @Description:
 * @Author: 美神猎手
 * @Date:   2020-06-05T15:21:06+08:00
 * @Email:  meishenlieshou@gmail.com
 * @Project: Datafor
 * @Filename: main.js
 * @Last modified by:   美神猎手
 * @Last modified time: 2020-06-17T16:51:51+08:00
 * @License: 收费
 * @Copyright: 上海数为信息技术有限公司
 */
importScripts("lodash.js");
importScripts("tinycolor.js");

//var _POINT_CACHE = JSON.parse(localStorage.getItem('LocationLngLat') || "{}");



function getGISTopNdataset(data) {
    function getTopN(list, topcount, callback, drilled) {
        var checkComplete = function(item, _point) {
            _point && pArray.push({
                point: _point,
                id: _point.lng + ':' + _point.lat,
                data: item.data,
                levels: item.levels,
                measures: item.measures,
                name: item.name,
                mName: item.mName,
                caption: item.caption,
                sum: item.sum,
                formatted: item.formatted
            });
            pArray.count--;
            if (pArray.count > 0) return false;
            pArray = pArray.sort(function(a, b) {
                return b.sum - a.sum;
            }).slice(0, topcount);
            callback(pArray);
            return true;
        };
        var pArray = new Array();
        var myself = this;
        var array = new Array();
        var batch = 0;
        var step = function() {
            var item = list.shift();
            var done;
            var _p;
            if (!item) { //可能已经完成任务
                checkComplete(null, null) || step();
            } else {
                checkComplete(item, {
                    lng: item.longitude,
                    lat: item.latitude
                }) || step();
            }
        };
        pArray.count = list.length;
        step();
        return this;
    }

    var getExtroMeasuresMinMax = function(series, configs) {
        var list = new Array();
        var based;
        if (!Array.isArray(series) || series.length == 0 || !configs || !configs.based) {
            return null;
        }
        based = '[Measures].[' + configs.based.id + ']';
        series.every(function(o) {
            var k = o.data.map(function(ii) {
                var val = ii.value;
                if (ii.measures[0].hasOwnProperty(based)) {
                    val = (Number(ii.measures[0][based]) || 0);
                }
                return val;
            });
            list = list.concat(k);
            return true;
        });
        return {
            min: Math.min.apply(null, list),
            max: Math.max.apply(null, list)
        };
    };
    var colorAnalysis = function(configs, value, minV, maxV) {
        var type = configs.type;
        var color = null;
        var min;
        var mid;
        var max;
        var target;
        var h, l, s;
        var midV = (maxV + minV) / 2;
        if (Object.keys(configs).length == 0 || !configs.customize) {
            return color;
        }
        if (type == 'continues') {
            if (!configs.continues || Object.keys(configs.continues).length == 0) {
                return color;
            }
            target = configs.continues;
            if (value < minV || value > maxV) {
                return color;
            } else {
                color = tinycolor.mix(target.min, target.max, 100 * (value - minV) / (maxV - minV));
            }
            // else if (value >= minV && value < midV) {
            //     color = tinycolor.mix(target.min, target.mid, 100 * (value - minV) / (midV - minV));
            // } else if (value >= midV && value <= maxV) {
            //     color = tinycolor.mix(target.mid, target.max, 100 * (value - midV) / (maxV - midV));
            // }
            return color.toRgbString();
        } else {
            target = configs.rules;
            if (!Array.isArray(target) || target.length == 0) {
                return color;
            }
            target = _.find(configs.rules, function(o) {
                var start = o.start_value;
                var end = o.end_value;
                var ok = Boolean(_.isFunction(_calculateMap[o.start]) && _calculateMap[o.start](start, value));
                if (_.isFunction(_calculateMap[o.end])) {
                    ok = ok && _calculateMap[o.end](end, value);
                }
                return ok;
            });
            if (target) {
                return target.color;
            } else {
                return color;
            }
        }
        return color;
    };


    var current = data.current;
    var input = data.input;
    var output = input ? JSON.parse(JSON.stringify(input)) : current;
    var use = JSON.parse(JSON.stringify(output));
    var len = use.dotCount || 30;
    var style = use.style || {};
    var existArray = data.exist || [];
    var minSize = style.min || 20;
    var maxSize = style.max || 45;
    var datasets = data.datasets;
    var colorConfigs = use.color_configs;
    // //没有指定经纬度的数据点
    // var unLocationPoints = datasets.filter(function(o) {
    //     return o.longitude || o.latitude;
    // });
    var list = getTopN(datasets, len, function(result) {
        var min = result.length ? Math.min(result[0].sum, result[result.length - 1].sum) : 0;
        var max = result.length ? Math.max(result[0].sum, result[result.length - 1].sum) : min;
        var u;
        var extrime;
        if (min == max) {
            u = 0;
        } else {
            u = (maxSize - minSize) / (max - min);
        }
        extrime = getExtroMeasuresMinMax(result.map(function(o) {
            return {
                data: [{
                    measures: o.measures
                }]
            };
        }), colorConfigs); //min,max;
        result.every(function(item) {
            var based;
            if (colorConfigs && colorConfigs.customize) {
                based = '[Measures].[' + colorConfigs.based.id + ']';
                item.color = colorAnalysis(colorConfigs, Number(item.measures[0][based]) || 0, extrime.min, extrime.max);
            }
            item.size = maxSize - (max - item.sum) * u;
            item.keyPoint = item.levels.map(function(o) {
                return o.uniqueName;
            }).join('~');
            return true;
        });
        //避免频繁计算
        setTimeout(function() {
            postMessage({
                datasets: result,
                output: output,
                min: min,
                max: max
            });
        }, 200);
    }, false);
};

/**
 * 地理编码
 * @param       {[type]}                 data
 * {
 *    key: "",
 *    datasets: [{
 *        name: '',
 *        city: '' //不指定，则全国范围内
 *    }, ...]
 * }
 * @constructor
 * @usage:
 * @author: 美神猎手
 * @email:      meishenlieshou@gmail.com
 * @copyrights: 上海数为信息技术有限公司
 * @time:       2020-06-07T10:21:56+080
 */
function GetLocationFromPlace(data, callback_block) {
    var key = data.key || "0b89be9f3d91140c290d1dffa678ea0a";
    var baseUrl = 'https://restapi.amap.com/v3/geocode/geo';
    var list = (data.datasets || []).map(function(o) {
        o.city = o.city || "全国";
        o.name = o.name || o.caption;
        return o;
    });
    var size = list.length;
    var complete = function() {
        var result = list.filter(function(o) {
            return o.longitude && o.latitude;
        });
        data.storage = result.map(function(item) {
            return {
                name: item.caption,
                longitude: item.longitude,
                latitude: item.latitude
            };
        });
        data.datasets = result;
        callback_block ? callback_block(result) : postMessage(data);
    };
    list.every(function(item) {
        var keyName = item.name;
        var xhr;
        xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            var arr;
            var data;
            if (xhr.readyState == 4) {
                if (xhr.status == 200) {
                    try {
                        data = JSON.parse(xhr.responseText).geocodes[0].location;
                        arr = data.split(',');
                        item.longitude = arr[0];
                        item.latitude = arr[1];
                    } catch (e) {
                        data = null;
                    }
                }
                size--;
                if (size <= 0) {
                    complete();
                }
            }
        };
        xhr.open("GET", baseUrl + '?address=' + encodeURI(keyName) + '&type=JSON&city=' + item.city + '&batch=false&key=' + key, true);
        xhr.send();
        return true;
    });
}

addEventListener("message", function(event) {
    var message = event.data;
    var type = message.type;
    switch (type) {
        case "getGISTopN":
            getGISTopNdataset(message.data);
            break;

        case "GetLocationFromPlace":
            GetLocationFromPlace(message.data);
            break;
        default:
            break;
    }
});